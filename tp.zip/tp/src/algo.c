#include "algo.h"

/**
 * Randomly fill the first generation.
 * Make sure that all towns are only
 * once in each individuals !
 */
void genese (int population_size, int population[population_size][NUMBER_OF_TOWNS])
{

}

/**
 *
 */
void adaptation_and_selection (int population_size, int population[population_size][NUMBER_OF_TOWNS])
{

}

/**
 *
 */
void reproduction (int population_size, int population[population_size][NUMBER_OF_TOWNS])
{

}

/**
 *
 */
void mutation (int population_size, int population[population_size][NUMBER_OF_TOWNS])
{

}

/**
 *
 */
void display_best (int population_size, int population[population_size][NUMBER_OF_TOWNS])
{

}
